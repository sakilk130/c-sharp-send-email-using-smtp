﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;

namespace Email
{
    public partial class Email : Form
    {
        public Email()
        {
            InitializeComponent();
        }

        private void Email_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textTo.Text=="" && textSubject.Text=="" && textAttatchment.Text=="" && textMessage.Text=="")
            {
                MessageBox.Show("Please Fill Up");
            }
            else
            {
                try
                {
                    SmtpClient clint = new SmtpClient("smtp.gmail.com", 587);
                    clint.EnableSsl = true;
                    clint.DeliveryMethod = SmtpDeliveryMethod.Network;
                    clint.UseDefaultCredentials = false;
                    clint.Credentials = new NetworkCredential("Enter Your Email", "Enter Your Password");
                    MailMessage msg = new MailMessage();
                    msg.To.Add(textTo.Text);
                    msg.From = new MailAddress("Enter Your Email");
                    msg.Subject = textSubject.Text;
                    msg.Body = textMessage.Text;
                    Attachment data = new Attachment(textAttatchment.Text);
                    msg.Attachments.Add(data);
                    clint.Send(msg);
                    MessageBox.Show("Mail Sent");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textAttatchment.Text = dlg.FileName.ToString();

            }
        }

        private void textTo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textSubject_TextChanged(object sender, EventArgs e)
        {

        }

        private void textAttatchment_TextChanged(object sender, EventArgs e)
        {

        }

        private void textMessage_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
